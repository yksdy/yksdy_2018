This contains classes for integrating Yahoo! Search in your Flash application. 

It is written in ActionScript 3.0 to target Flash Player 9 and above. You may use this class in your Flash 9, Flex 2, or Apollo application.

For Flash:
Start with the Flash9Example.fla file and build it in Flash 9.

For Flex 2 / Apollo:
Import this as a Library and point your project to the library, or copy this source directly into your own project.
See http://developer.yahoo.com/flash/as3_api_libraries.html#install for a full explanation.


See docs/index.html for API documentation