LICENSE 
Copyright 2006 Raymond Camden

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
   
   
If you find this code worthy, I have a Amazon wish list set up (www.amazon.com/o/registry/2TCL1D08EZEYE ). Gifts are always welcome. ;)

Last Updated: February 26, 2007 (0.9)
search.cfc - check for error in returned xml

Last Updated: February 26, 2007 (0.8)
locale.cfc - Code now checks lastreviewdate to ensure it isn't empty.

Last Updated: January 5, 2007 (0.7)
Addition of installation instructions. These are not complete, but cover installing, getting an application key, and the Answers API.
/org/camden/yahoo/base.cfc - Removed my application key from the code.

