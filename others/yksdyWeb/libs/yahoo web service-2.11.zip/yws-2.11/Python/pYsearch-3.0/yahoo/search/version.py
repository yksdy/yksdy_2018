""" yahoo.search.version - Version information
"""

version = "3.0"
authorName = "Leif Hedstrom"
authorMail = "leif@ogre.com"
maintainerName = "Leif Hedstrom"
maintainerMail = "leif@ogre.com"
credits = """- The entire Yahoo search team, of course.
"""

author = "%s <%s>" % (authorName, authorMail)


__revision__ = "$Id: version.py,v 1.12 2007/02/28 05:22:43 zwoop Exp $"
__version__ = "$Revision: 1.12 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Tue Feb 27 22:22:37 MST 2007"



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
